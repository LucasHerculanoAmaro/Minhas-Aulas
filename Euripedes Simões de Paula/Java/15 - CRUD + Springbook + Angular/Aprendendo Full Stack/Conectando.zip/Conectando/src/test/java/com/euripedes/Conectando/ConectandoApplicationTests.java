package com.euripedes.Conectando;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConectandoApplicationTests {

	@Test
	void contextLoads() {
	}

}
